window.WREN_CONFIG = {
  provider: "gemini",
  model: "gemini-3.8-flash",
  apiKey: "AQ.Ab8RN6K_1OFgnWqHCH5dDR3nFp5a9IZvd4o7JbI6uNrpnWhZ4g",
  thinking: "low",
  temperature: 0.8,
  maxTokens: 2048,
  timeoutMs: 30000
};
