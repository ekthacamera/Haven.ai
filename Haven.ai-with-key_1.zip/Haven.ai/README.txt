HAVEN.AI
A calm place to talk, then a space to let it out or slow down.

WHAT'S INSIDE
  index.html        Start here. Wren, the wellbeing guide.
  brassrail.html    Brass Rail: smash room and garage
  stonewater.html   Stonewater: stone skipping and rifle range
  lanternlake.html  Lantern Lake: breathing on a lake at dusk
  sakura.html       Sakura Sanctuary
  wren-config.js    Settings for Wren's AI (no key is stored here)

HOW TO OPEN IT
  1. Download the whole Haven.ai folder from Google Drive and unzip it.
     (Drive can't run it in the preview window.)
  2. Keep all the files in the same folder.
  3. Double-click index.html. Chrome or Edge works best.
  4. You need an internet connection (the 3D engine loads online).

VR (Meta Quest)
  Open the site in the Quest Browser and press "Enter VR" inside a simulation.

WREN'S AI
  Wren is connected to Google Gemini (the key is in wren-config.js), so she
  talks with real AI and can use the natural Gemini voice. If there's no
  internet or the key stops working, she falls back to her built-in replies.

Wren is a wellbeing guide, not a doctor or therapist.
In India, Tele-MANAS is free and open 24x7: 14416.
